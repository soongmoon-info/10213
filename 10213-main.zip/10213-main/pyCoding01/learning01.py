

#print(10+20) 
#print('10'+'20')

#num1=int(input('첫번쨰 숫자 입력:'))
#num2=int(input('두번쨰 숫자 입력:'))
#print('두 수의 합:',num1+num2)


age=input()
print()
